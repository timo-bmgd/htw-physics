/* template GTAT2 Game Technology & Interactive Systems */
/* Autor: Timo Boomgaarden */
/* Übung Nr. 1 */
/* Datum: 11.10.23 */

/* declarations */ 
var canvasWidth = window.innerWidth;
var canvasHeight = window.innerHeight;
var y = 500;

/* prepare program */
function setup() {								
  createCanvas(windowWidth, windowHeight);
}
/* run program */
function draw() {									
  background("white");
  /* blue ground floor */
	fill("blue");
  noStroke();
	rectMode(CORNERS);
	rect(100,y,840,y-50);
  rect(840,y,860,y-25)
  rect(860,y,1100,y-50);
  triangle(1000,y-50,1100,y-50,1100,y-100)
  /* wall */
  fill("gray");
  rect(1100,y,1200,0);


  /* cannon */
  rotatedRect(100,y-50,100,8,frameCount,"gray")
  /* zero point */
  fill("black")
  circle(100,y-50,10)
  /* flag */
  rect(875,y-50,879,y-200)
  fill("yellow")
  stroke("grey")
  triangle(879,y-200,879,y-150,929,y-175)
  noStroke();
  /* enemy ball */
  fill("red")
  circle(400,y-60,20)
  /* player ball*/
  fill("green")
  circle(500,y-60,20)		




  pop();
/* display */
}

/* isr */
function windowResized() {						/* responsive design */
  canvasWidth = window.innerWidth;
  canvasHeight = window.innerHeight;
  resizeCanvas(windowWidth, windowHeight);
}
