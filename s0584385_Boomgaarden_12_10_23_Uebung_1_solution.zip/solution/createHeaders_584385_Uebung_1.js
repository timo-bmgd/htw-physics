var h = document.createElement("HEADER");
h.textContent

document.getElementById()