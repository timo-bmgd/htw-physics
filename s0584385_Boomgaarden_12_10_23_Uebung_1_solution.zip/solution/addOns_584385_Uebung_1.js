/* template GTAT2 Game Technology & Interactive Systems - addOns */
/* Autor:  */
/* Übung Nr. */
/* Datum: */

fill("red");
rect(20,20,40,40);

/* draw red rectangle */
function rotatedRect(sx,sy,width,height,angle,color){
	push();
	fill(color)
	//Create Rotated Rectangle
	let transOffset = -height/2
	
	//Reset to Origin
	translate(sx,sy)

	//Rotate by Angle Amount (converted from degrees to radians)
	rotate(radians(angle));

	//Center pivot
	translate(0,transOffset)

	//Draw
	rect(0,0,width,height)
	pop();
}
